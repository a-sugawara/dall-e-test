export const conditionalRender = (condition, render) => {
    return condition? render : null
}
