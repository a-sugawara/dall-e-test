import React from 'react'

export default function ContactScreen() {
  return (
    <div className="main">
      <div className='response-wrapper'>
        "ContactScreen"
      </div>
    </div>
  )
}
