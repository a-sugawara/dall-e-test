export const setPrompt = (prompt) => {
    return{
        type: "setPrompt",
        prompt
    }
}
export const setStyle = (style) => {
    return{
        type: "setStyle",
        style
    }
}
