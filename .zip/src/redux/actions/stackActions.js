export const addStack = (screen) => {
    return {
        type: "addStack",
        screen
    }
}
export const popStack = {
    type: "popStack",
}
