export const menuToggle = {
    type:"menuToggle"
}
