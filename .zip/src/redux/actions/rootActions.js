export const clearCache = {
    type: "clear"
}
