import { mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import LoadingOverlay from '../../../../components/common/overlays/loadingOverlay'


describe('<TemplateList />', () => {
  it('Should be',() => {
    expect(true).toEqual(true)
  })
})
